import sys

a = 42

