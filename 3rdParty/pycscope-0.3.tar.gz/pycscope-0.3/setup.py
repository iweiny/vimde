#!/usr/bin/env python

from distutils.core import setup

setup(name="pycscope",
      version="0.3",
      description="Generates a cscope index of Python source trees",
      author="Dean Hall",
      author_email="dwhall256\x40yahoo\x2Ecom",
      url="None",
      scripts=['pycscope.py',],
     )
